import {
  initializeDeckVERSION,
  initializeDeckPREFIX,
  initializeDeckIDENT,
  initializeDeckMAX_VISIBLE,
  initializeDeckEMPTY_FIELDS,
  initializeDeckLANGUAGE_OPTIONS,
  initializeDeckANY_ONLY_EXCLUDE,
  initializeDeckBLOCK_MEDIA,
  initializeDeckBLOCK_TYPES,
  initializeDeckMAX_BLOCK_NODES,
  initializeDeckMAX_BLOCK_DEPTH,
  initializeDeckSORTS,
  initializeDeckGROUPS,
} from "../config/search.js";
import { initializeDeckState } from "../state/deck.js";
import { initializeDeckCopyFields } from "../search/blocks.js";
import {
  initializeDeckHtml,
  initializeDeckUid,
  initializeDeckTokens,
  initializeDeckSplitAccounts,
} from "../shared/text.js";
import { initializeDeckQueryEngine } from "../search/query-compiler.js";
import { initializeDeckSignature } from "../search/block-editing.js";
import {
  initializeDeckModernGM,
  initializeDeckGmGet,
  initializeDeckGmSet,
  initializeDeckGmAvailable,
  initializeDeckStorage,
  initializeDeckRecoveryKey,
} from "../storage/persistence.js";
import { initializeDeckCloudSync } from "../sync/cloud.js";
import { initializeDeckImmersiveDownload } from "../media/download.tsx";
import { initializeDeckRelay } from "../telegram/relay.tsx";
import { initializeDeckXRepost } from "../tweets/publisher.tsx";
import { initializeDeckXClientLists } from "../lists/client.js";
import { initializeDeckProfileLists } from "../lists/profile.tsx";
import { initializeDeckFeedFilters } from "../feeds/filters.tsx";
import { initializeDeckScrollChrome } from "../layout/chrome.tsx";
import { initializeDeckCompactLayout } from "../layout/tweets.tsx";
import { initializeDeckPreferences } from "../ui/preferences.tsx";
import { initializeDeckDirectLinks } from "../links/direct.js";
import { initializeDeckSocialAppLinks } from "../links/social.tsx";
import { initializeDeckVideoTapGuard } from "../media/gestures.tsx";
import { initializeDeckQuickRepost } from "../tweets/quick-repost.js";
import { initializeDeckSeen } from "../tweets/seen.js";
import { initializeDeckNativeTranslation } from "../translation/native.js";
import { initializeDeckForeignTags } from "../translation/foreign-tags.tsx";
import { initializeDeckVideoExperience } from "../media/playback.js";
import { initializeDeckSeekPreviews } from "../media/seek-preview.tsx";
import { initializeDeckPlayerPreference } from "../media/player.tsx";
import { initializeDeckSearchAnchors } from "../search/anchors.tsx";
import { initializeDeckVideoTransport } from "../media/transport.tsx";
import { initializeDeckViewportPlayback } from "../media/playback.js";
import { initializeDeckImmersiveSwipe } from "../media/gestures.tsx";
import { initializeDeckNativeQueryTags } from "../search/native-tags.js";
import { initializeDeckResultEnhancer } from "../tweets/enhancer.tsx";
import { initializeDeckRodxToastTimer } from "../ui/runtime.tsx";
import { initializeDeckDragDock } from "../ui/dock.tsx";
import {
  initializeRodX_deck_164,
  initializeRodX_deck_169,
  initializeRodX_deck_170,
  initializeRodX_deck_171,
  initializeRodX_deck_172,
  initializeRodX_deck_173,
  initializeRodX_deck_175,
  initializeRodX_deck_176,
  initializeRodX_deck_177,
  initializeRodX_deck_178,
  initializeRodX_deck_179,
  initializeRodX_deck_180,
  initializeRodX_deck_181,
  initializeRodX_deck_182,
  initializeRodX_deck_183,
  initializeDeckDatabaseSaveTimerAndRefreshingCloud,
  initializeRodX_deck_185,
  initializeRodX_deck_186,
  initializeRodX_deck_187,
  initializeRodX_deck_188,
  initializeRodX_deck_189,
  initializeRodX_deck_190,
  initializeRodX_deck_191,
  initializeRodX_deck_192,
  initializeRodX_deck_193,
  initializeRodX_deck_194,
  initializeRodX_deck_195,
  initializeRodX_deck_196,
  initializeRodX_deck_197,
  initializeRodX_deck_198,
  initializeRodX_deck_199,
} from "./deck-events.js";
import { initializeDeckSelectionPopover } from "../ui/selection.tsx";
import { initializeDeckXInterfaceHygiene } from "../layout/hygiene.tsx";
import { initializeDeckSearchHistory } from "../search/history.tsx";
import { initializeDeckQuickUI } from "../ui/quick-actions.tsx";

function runInitializers(...initializers) {
  for (const initialize of initializers) {
    initialize();
  }
}

export function initializeDeck() {
  // Cada fase mantém a ordem histórica de inicialização do Deck.
  runInitializers(
    // Configuração, estado e compilação.
    initializeDeckVERSION,
    initializeDeckPREFIX,
    initializeDeckIDENT,
    initializeDeckMAX_VISIBLE,
    initializeDeckEMPTY_FIELDS,
    initializeDeckLANGUAGE_OPTIONS,
    initializeDeckANY_ONLY_EXCLUDE,
    initializeDeckBLOCK_MEDIA,
    initializeDeckBLOCK_TYPES,
    initializeDeckMAX_BLOCK_NODES,
    initializeDeckMAX_BLOCK_DEPTH,
    initializeDeckSORTS,
    initializeDeckGROUPS,
    initializeDeckState,
    initializeDeckCopyFields,
    initializeDeckHtml,
    initializeDeckUid,
    initializeDeckTokens,
    initializeDeckSplitAccounts,
    initializeDeckQueryEngine,
    initializeDeckSignature,

    // GM, storage e sincronização.
    initializeDeckModernGM,
    initializeDeckGmGet,
    initializeDeckGmSet,
    initializeDeckGmAvailable,
    initializeDeckStorage,
    initializeDeckRecoveryKey,
    initializeDeckCloudSync,

    // Integrações e superfície do Deck.
    initializeDeckImmersiveDownload,
    initializeDeckRelay,
    initializeDeckXRepost,
    initializeDeckXClientLists,
    initializeDeckProfileLists,
    initializeDeckFeedFilters,
    initializeDeckScrollChrome,
    initializeDeckCompactLayout,
    initializeDeckPreferences,
    initializeDeckDirectLinks,
    initializeDeckSocialAppLinks,
    initializeDeckVideoTapGuard,
    initializeDeckQuickRepost,
    initializeDeckSeen,
    initializeDeckNativeTranslation,
    initializeDeckForeignTags,

    // Mídia, busca e aprimoramentos.
    initializeDeckVideoExperience,
    initializeDeckSeekPreviews,
    initializeDeckPlayerPreference,
    initializeDeckSearchAnchors,
    initializeDeckVideoTransport,
    initializeDeckViewportPlayback,
    initializeDeckImmersiveSwipe,
    initializeDeckNativeQueryTags,
    initializeDeckResultEnhancer,
    initializeDeckRodxToastTimer,
    initializeDeckDragDock,

    // Eventos legados e módulos finais.
    initializeRodX_deck_164,
    initializeDeckSelectionPopover,
    initializeDeckXInterfaceHygiene,
    initializeDeckSearchHistory,
    initializeRodX_deck_169,
    initializeRodX_deck_170,
    initializeRodX_deck_171,
    initializeRodX_deck_172,
    initializeRodX_deck_173,
    initializeDeckQuickUI,
    initializeRodX_deck_175,
    initializeRodX_deck_176,
    initializeRodX_deck_177,
    initializeRodX_deck_178,
    initializeRodX_deck_179,
    initializeRodX_deck_180,
    initializeRodX_deck_181,
    initializeRodX_deck_182,
    initializeRodX_deck_183,
    initializeDeckDatabaseSaveTimerAndRefreshingCloud,
    initializeRodX_deck_185,
    initializeRodX_deck_186,
    initializeRodX_deck_187,
    initializeRodX_deck_188,
    initializeRodX_deck_189,
    initializeRodX_deck_190,
    initializeRodX_deck_191,
    initializeRodX_deck_192,
    initializeRodX_deck_193,
    initializeRodX_deck_194,
    initializeRodX_deck_195,
    initializeRodX_deck_196,
    initializeRodX_deck_197,
    initializeRodX_deck_198,
    initializeRodX_deck_199,
  );
}
